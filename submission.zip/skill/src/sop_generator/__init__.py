"""Sales SOP generation package."""
